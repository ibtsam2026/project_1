document.querySelectorAll('pre code').forEach(c=>{
  c.addEventListener('click',()=>{
    navigator.clipboard?.writeText(c.innerText);
  });
});